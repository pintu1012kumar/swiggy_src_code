const Contact = () => {
    return (
        <div>
            <h1>Contact Us</h1>
            <h4>Let's connect with Me</h4>
        </div>
    );
};

export default Contact;