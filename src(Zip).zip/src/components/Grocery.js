// **** Assume this as a large component (having a lots of sub/child-component ) ****

const Grocery = () => {
    return (
        <h1>
            Our Grocery online store, and we have a lot of child components inside this web pages !!
        </h1>
    );
};

export default Grocery;